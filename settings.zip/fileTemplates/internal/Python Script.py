# -*- coding: utf-8 -*-
"""
-------------------------------------------------
Project Name: ${PROJECT_NAME}
File Name: ${NAME}.py
Author: Tridagger
Email: san.limeng@qq.com
Create Date: ${DATE}
-------------------------------------------------
"""  